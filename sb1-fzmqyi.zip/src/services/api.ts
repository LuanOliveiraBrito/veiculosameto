import axios from 'axios';
import { Vehicle, Driver, VehicleHistory } from '../types';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

export const getVehicles = () => api.get<Vehicle[]>('/vehicles');
export const getDrivers = () => api.get<Driver[]>('/drivers');
export const getHistory = () => api.get<VehicleHistory[]>('/history');

export const checkoutVehicle = async (vehicleId: string, driverId: string) => {
  return api.post('/vehicles/checkout', { vehicleId, driverId });
};

export const returnVehicle = async (vehicleId: string) => {
  return api.post('/vehicles/return', { vehicleId });
};