import React, { useEffect, useState } from 'react';
import { Vehicle, Driver, VehicleHistory } from './types';
import { VehicleCard } from './components/VehicleCard';
import { VehicleHistoryList } from './components/VehicleHistory';
import { getVehicles, getDrivers, getHistory, checkoutVehicle, returnVehicle } from './services/api';
import { Car } from 'lucide-react';

function App() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [drivers, setDrivers] = useState<Driver[]>([]);
  const [history, setHistory] = useState<VehicleHistory[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      const [vehiclesRes, driversRes, historyRes] = await Promise.all([
        getVehicles(),
        getDrivers(),
        getHistory()
      ]);

      setVehicles(vehiclesRes.data);
      setDrivers(driversRes.data);
      setHistory(historyRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCheckout = async (vehicleId: string, driverId: number) => {
    try {
      await checkoutVehicle(vehicleId, driverId);
      await fetchData();
    } catch (error) {
      console.error('Error checking out vehicle:', error);
    }
  };

  const handleReturn = async (vehicleId: string) => {
    try {
      await returnVehicle(vehicleId);
      await fetchData();
    } catch (error) {
      console.error('Error returning vehicle:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-xl">Carregando...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center mb-8">
          <Car className="w-8 h-8 mr-3 text-blue-600" />
          <h1 className="text-3xl font-bold text-gray-900">
            Controle de Veículos
          </h1>
        </div>

        <div className="grid gap-6">
          {vehicles.map((vehicle) => (
            <div key={vehicle.id}>
              <VehicleCard
                vehicle={vehicle}
                drivers={drivers}
                onCheckout={handleCheckout}
                onReturn={handleReturn}
              />
              <VehicleHistoryList
                history={history}
                drivers={drivers}
                vehicleId={vehicle.id}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;