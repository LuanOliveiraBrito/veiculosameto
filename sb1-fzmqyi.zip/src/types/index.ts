export interface Vehicle {
  id: string;
  model: string;
  isCheckedOut: boolean;
  currentDriver: string | null;
}

export interface Driver {
  id: string;
  name: string;
  department: string;
}

export interface VehicleHistory {
  id: number;
  vehicleId: string;
  driverId: string;
  checkoutTime: string;
  returnTime: string | null;
  vehicleModel?: string;
  driverName?: string;
  driverDepartment?: string;
}