import express from 'express';
import cors from 'cors';
import initSqlJs from 'sql.js';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const dbFile = join(__dirname, 'vehicles.db');

let db;
let SQL;

async function initializeDatabase() {
  SQL = await initSqlJs();
  
  try {
    if (fs.existsSync(dbFile)) {
      const filebuffer = fs.readFileSync(dbFile);
      db = new SQL.Database(filebuffer);
    } else {
      db = new SQL.Database();
      initializeTables();
      saveDatabase();
    }
  } catch (err) {
    console.error('Error initializing database:', err);
    db = new SQL.Database();
    initializeTables();
    saveDatabase();
  }
}

function initializeTables() {
  db.run(`
    CREATE TABLE IF NOT EXISTS vehicles (
      id TEXT PRIMARY KEY,
      model TEXT NOT NULL,
      isCheckedOut BOOLEAN DEFAULT FALSE,
      currentDriver TEXT
    );

    CREATE TABLE IF NOT EXISTS drivers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      department TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vehicleId TEXT NOT NULL,
      driverId TEXT NOT NULL,
      checkoutTime DATETIME DEFAULT CURRENT_TIMESTAMP,
      returnTime DATETIME,
      FOREIGN KEY (vehicleId) REFERENCES vehicles (id),
      FOREIGN KEY (driverId) REFERENCES drivers (id)
    );
  `);

  // Initialize default data
  const vehicles = db.exec("SELECT COUNT(*) as count FROM vehicles")[0].values[0][0];
  const drivers = db.exec("SELECT COUNT(*) as count FROM drivers")[0].values[0][0];

  if (vehicles === 0) {
    db.run("INSERT INTO vehicles (id, model, isCheckedOut) VALUES (?, ?, FALSE)", ['RSB7C87', 'NISSAN VERSA']);
    db.run("INSERT INTO vehicles (id, model, isCheckedOut) VALUES (?, ?, FALSE)", ['QKE1B38', 'HILUX MARCELO']);
    db.run("INSERT INTO vehicles (id, model, isCheckedOut) VALUES (?, ?, FALSE)", ['QKI7G71', 'PRESIDÊNCIA']);
    db.run("INSERT INTO vehicles (id, model, isCheckedOut) VALUES (?, ?, FALSE)", ['QKE1B6', 'HILUX ADMINISTRAÇÃO']);
  }

  if (drivers === 0) {
    db.run("INSERT INTO drivers (id, name, department) VALUES (?, ?, ?)", 
      ['1', 'Luan Oliveira de Brito Nunes', 'Administração']);
    db.run("INSERT INTO drivers (id, name, department) VALUES (?, ?, ?)", 
      ['2', 'José Borges', 'Motorista']);
  }
}

function saveDatabase() {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbFile, buffer);
}

const app = express();
app.use(cors());
app.use(express.json());

// Initialize database before starting server
await initializeDatabase();

app.get('/api/vehicles', (req, res) => {
  const result = db.exec('SELECT * FROM vehicles');
  const vehicles = result.length > 0 ? result[0].values.map(row => ({
    id: row[0],
    model: row[1],
    isCheckedOut: Boolean(row[2]),
    currentDriver: row[3]
  })) : [];
  res.json(vehicles);
});

app.get('/api/drivers', (req, res) => {
  const result = db.exec('SELECT * FROM drivers');
  const drivers = result.length > 0 ? result[0].values.map(row => ({
    id: row[0],
    name: row[1],
    department: row[2]
  })) : [];
  res.json(drivers);
});

app.get('/api/history', (req, res) => {
  const result = db.exec(`
    SELECT h.id, h.vehicleId, h.driverId, h.checkoutTime, h.returnTime,
           v.model as vehicleModel, d.name as driverName, d.department as driverDepartment
    FROM history h
    JOIN vehicles v ON h.vehicleId = v.id
    JOIN drivers d ON h.driverId = d.id
    ORDER BY h.checkoutTime DESC
  `);
  
  const history = result.length > 0 ? result[0].values.map(row => ({
    id: row[0],
    vehicleId: row[1],
    driverId: row[2],
    checkoutTime: row[3],
    returnTime: row[4],
    vehicleModel: row[5],
    driverName: row[6],
    driverDepartment: row[7]
  })) : [];
  
  res.json(history);
});

app.post('/api/vehicles/checkout', (req, res) => {
  const { vehicleId, driverId } = req.body;
  
  try {
    const vehicle = db.exec('SELECT isCheckedOut FROM vehicles WHERE id = ?', [vehicleId])[0];
    if (vehicle && Boolean(vehicle.values[0][0])) {
      return res.status(400).json({ error: 'Vehicle is already checked out' });
    }

    db.run('BEGIN TRANSACTION');
    
    db.run(`
      UPDATE vehicles
      SET isCheckedOut = TRUE, currentDriver = ?
      WHERE id = ?
    `, [driverId, vehicleId]);

    db.run(`
      INSERT INTO history (vehicleId, driverId)
      VALUES (?, ?)
    `, [vehicleId, driverId]);

    db.run('COMMIT');
    saveDatabase();
    
    res.json({ success: true });
  } catch (error) {
    db.run('ROLLBACK');
    res.status(500).json({ error: 'Failed to checkout vehicle' });
  }
});

app.post('/api/vehicles/return', (req, res) => {
  const { vehicleId } = req.body;
  
  try {
    const vehicle = db.exec('SELECT isCheckedOut FROM vehicles WHERE id = ?', [vehicleId])[0];
    if (!vehicle || !Boolean(vehicle.values[0][0])) {
      return res.status(400).json({ error: 'Vehicle is not checked out' });
    }

    db.run('BEGIN TRANSACTION');
    
    db.run(`
      UPDATE vehicles
      SET isCheckedOut = FALSE, currentDriver = NULL
      WHERE id = ?
    `, [vehicleId]);

    db.run(`
      UPDATE history
      SET returnTime = CURRENT_TIMESTAMP
      WHERE vehicleId = ? AND returnTime IS NULL
    `, [vehicleId]);

    db.run('COMMIT');
    saveDatabase();
    
    res.json({ success: true });
  } catch (error) {
    db.run('ROLLBACK');
    res.status(500).json({ error: 'Failed to return vehicle' });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});